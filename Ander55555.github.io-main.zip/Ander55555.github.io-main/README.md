Hi This is the code for Labyrinth-games
Links For Labyrinth-games
<a href="https://labyrinth-games.neocities.org/">link 1 Neocities</a>
<a href="https://labyrinth-games.w3spaces.com/">link 2 W3spaces</a>
<a href="https://ander55555.github.io/">link 3 Github</a>
